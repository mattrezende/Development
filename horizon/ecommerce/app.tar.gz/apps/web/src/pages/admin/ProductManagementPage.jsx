
import React, { useEffect, useState } from 'react';
import pb from '@/lib/pocketbaseClient';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Edit, Trash2, Image as ImageIcon } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import AdminLayout from '@/components/AdminLayout.jsx';

const ProductManagementPage = () => {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [subcategories, setSubcategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  
  const initialFormState = {
    name: '',
    description: '',
    price: '',
    category: '',
    subcategory: '',
    stock: '',
    discount: '0'
  };
  
  const [formData, setFormData] = useState(initialFormState);
  const [imageFile, setImageFile] = useState(null);
  const [currentImage, setCurrentImage] = useState(null);
  
  const { toast } = useToast();

  const fetchData = async () => {
    setLoading(true);
    try {
      const [productsRes, categoriesRes] = await Promise.all([
        pb.collection('products').getList(1, 50, { expand: 'category', sort: '-created', $autoCancel: false }),
        pb.collection('categories').getFullList({ sort: 'name', $autoCancel: false })
      ]);
      setProducts(productsRes.items);
      setCategories(categoriesRes);
    } catch (error) {
      console.error("Error fetching data:", error);
      toast({ variant: "destructive", title: "Erro", description: "Não foi possível carregar os dados." });
    } finally {
      setLoading(false);
    }
  };

  const fetchSubcategories = async (categoryId) => {
    if (!categoryId) {
      setSubcategories([]);
      return;
    }
    try {
      const res = await pb.collection('subcategories').getList(1, 50, {
        filter: `category_id="${categoryId}"`,
        sort: 'name',
        $autoCancel: false
      });
      setSubcategories(res.items);
    } catch (error) {
      console.error("Error fetching subcategories:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleOpenModal = (product = null) => {
    if (product) {
      setEditingId(product.id);
      setFormData({
        name: product.name,
        description: product.description || '',
        price: product.price.toString(),
        category: product.category,
        subcategory: product.subcategory || product.subcategory_id || '',
        stock: product.stock.toString(),
        discount: (product.discount || 0).toString()
      });
      setCurrentImage(product.image ? pb.files.getUrl(product, product.image) : null);
      
      if (product.category) {
        fetchSubcategories(product.category);
      } else {
        setSubcategories([]);
      }
    } else {
      setEditingId(null);
      setFormData(initialFormState);
      setCurrentImage(null);
      setSubcategories([]);
    }
    setImageFile(null);
    setIsModalOpen(true);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCategoryChange = (value) => {
    setFormData(prev => ({ ...prev, category: value, subcategory: '' }));
    fetchSubcategories(value);
  };

  const handleSubcategoryChange = (value) => {
    setFormData(prev => ({ ...prev, subcategory: value === 'none' ? '' : value }));
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      setImageFile(e.target.files[0]);
      setCurrentImage(URL.createObjectURL(e.target.files[0]));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.price || !formData.category || !formData.stock) {
      toast({ variant: "destructive", title: "Erro de Validação", description: "Preencha todos os campos obrigatórios." });
      return;
    }

    setSaving(true);
    try {
      const data = new FormData();
      data.append('name', formData.name);
      data.append('description', formData.description);
      data.append('price', parseFloat(formData.price));
      data.append('category', formData.category);
      data.append('stock', parseInt(formData.stock, 10));
      data.append('discount', parseFloat(formData.discount || 0));
      
      if (formData.subcategory) {
        data.append('subcategory_id', formData.subcategory);
        data.append('subcategory', formData.subcategory); // Adding both to ensure compatibility
      }
      
      if (imageFile) {
        data.append('image', imageFile);
      }

      if (editingId) {
        await pb.collection('products').update(editingId, data, { $autoCancel: false });
        toast({ title: "Sucesso", description: "Produto atualizado com sucesso!" });
      } else {
        await pb.collection('products').create(data, { $autoCancel: false });
        toast({ title: "Sucesso", description: "Produto criado com sucesso!" });
      }
      
      setIsModalOpen(false);
      fetchData();
    } catch (error) {
      console.error("Error saving product:", error);
      toast({ 
        variant: "destructive", 
        title: "Erro ao salvar", 
        description: error.response?.message || "Ocorreu um erro inesperado ao salvar o produto." 
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Tem certeza que deseja excluir este produto? Esta ação não pode ser desfeita.')) {
      try {
        await pb.collection('products').delete(id, { $autoCancel: false });
        toast({ title: "Sucesso", description: "Produto excluído com sucesso." });
        fetchData();
      } catch (error) {
        console.error("Error deleting product:", error);
        toast({ variant: "destructive", title: "Erro ao excluir", description: "Não foi possível excluir o produto." });
      }
    }
  };

  return (
    <AdminLayout>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Gerenciar Produtos</h1>
        <Button onClick={() => handleOpenModal()}>
          <Plus className="mr-2 h-4 w-4" /> Novo Produto
        </Button>
      </div>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingId ? 'Editar Produto' : 'Novo Produto'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-6 mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome do Produto *</Label>
                  <Input id="name" name="name" value={formData.name} onChange={handleInputChange} required />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="category">Categoria *</Label>
                  <Select value={formData.category} onValueChange={handleCategoryChange} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione uma categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(cat => (
                        <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="subcategory">Subcategoria (Opcional)</Label>
                  <Select 
                    value={formData.subcategory || 'none'} 
                    onValueChange={handleSubcategoryChange}
                    disabled={!formData.category || subcategories.length === 0}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={
                        !formData.category ? "Selecione uma categoria primeiro" : 
                        subcategories.length === 0 ? "Nenhuma subcategoria disponível" : 
                        "Selecione uma subcategoria"
                      } />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Nenhuma</SelectItem>
                      {subcategories.map(sub => (
                        <SelectItem key={sub.id} value={sub.id}>{sub.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="price">Preço (R$) *</Label>
                    <Input id="price" name="price" type="number" step="0.01" min="0" value={formData.price} onChange={handleInputChange} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="discount">Desconto (%)</Label>
                    <Input id="discount" name="discount" type="number" step="0.1" min="0" max="100" value={formData.discount} onChange={handleInputChange} />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="stock">Estoque *</Label>
                  <Input id="stock" name="stock" type="number" min="0" value={formData.stock} onChange={handleInputChange} required />
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea id="description" name="description" value={formData.description} onChange={handleInputChange} rows={4} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="image">Imagem do Produto</Label>
                  <div className="flex flex-col items-center justify-center border-2 border-dashed rounded-lg p-4 bg-muted/30 hover:bg-muted/50 transition-colors">
                    {currentImage ? (
                      <div className="relative w-full aspect-video mb-4 rounded-md overflow-hidden bg-black/5">
                        <img src={currentImage} alt="Preview" className="w-full h-full object-contain" />
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
                        <ImageIcon className="w-12 h-12 mb-2 opacity-50" />
                        <p className="text-sm">Nenhuma imagem selecionada</p>
                      </div>
                    )}
                    <Input id="image" type="file" accept="image/*" onChange={handleFileChange} className="w-full" />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-4 pt-4 border-t">
              <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)} disabled={saving}>
                Cancelar
              </Button>
              <Button type="submit" disabled={saving}>
                {saving ? 'Salvando...' : 'Salvar Produto'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <div className="bg-card border rounded-xl overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-16">Img</TableHead>
              <TableHead>Nome</TableHead>
              <TableHead>Categoria</TableHead>
              <TableHead>Preço</TableHead>
              <TableHead>Estoque</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan={6} className="text-center py-8">Carregando produtos...</TableCell></TableRow>
            ) : products.length === 0 ? (
              <TableRow><TableCell colSpan={6} className="text-center py-8">Nenhum produto encontrado.</TableCell></TableRow>
            ) : (
              products.map(product => (
                <TableRow key={product.id}>
                  <TableCell>
                    <div className="w-10 h-10 rounded bg-muted overflow-hidden flex items-center justify-center">
                      {product.image ? (
                        <img src={pb.files.getUrl(product, product.image)} alt={product.name} className="w-full h-full object-cover" />
                      ) : (
                        <ImageIcon className="w-4 h-4 text-muted-foreground" />
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">{product.name}</TableCell>
                  <TableCell>{product.expand?.category?.name || 'Sem categoria'}</TableCell>
                  <TableCell>
                    R$ {product.price.toFixed(2)}
                    {product.discount > 0 && <span className="ml-2 text-xs text-destructive">(-{product.discount}%)</span>}
                  </TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${product.stock > 10 ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' : product.stock > 0 ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400' : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'}`}>
                      {product.stock} un
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => handleOpenModal(product)} title="Editar">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive hover:bg-destructive/10" onClick={() => handleDelete(product.id)} title="Excluir">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </AdminLayout>
  );
};

export default ProductManagementPage;
