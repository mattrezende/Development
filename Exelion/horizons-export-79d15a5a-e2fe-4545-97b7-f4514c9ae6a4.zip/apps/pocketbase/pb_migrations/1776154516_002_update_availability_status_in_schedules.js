/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("schedules");
  const field = collection.fields.getByName("availability_status");
  field.values = ["Dispon\u00edvel", "Reservado", "Ocupado"];
  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("schedules");
  const field = collection.fields.getByName("availability_status");
  field.values = ["available", "reserved", "occupied"];
  return app.save(collection);
})