/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("enrollments");

  const existing = collection.fields.getByName("payment_method");
  if (existing) {
    if (existing.type === "select") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("payment_method"); // exists with wrong type, remove first
  }

  collection.fields.add(new SelectField({
    name: "payment_method",
    required: false,
    values: ["pix", "credit_card", "debit_card", "recurring"]
  }));

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("enrollments");
  collection.fields.removeByName("payment_method");
  return app.save(collection);
})