/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("enrollments");

  const existing = collection.fields.getByName("schedule_ids");
  if (existing) {
    if (existing.type === "text") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("schedule_ids"); // exists with wrong type, remove first
  }

  collection.fields.add(new TextField({
    name: "schedule_ids"
  }));

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("enrollments");
  collection.fields.removeByName("schedule_ids");
  return app.save(collection);
})