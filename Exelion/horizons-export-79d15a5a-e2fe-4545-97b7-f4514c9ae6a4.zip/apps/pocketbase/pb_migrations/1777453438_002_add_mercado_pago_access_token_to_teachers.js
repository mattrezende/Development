/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("teachers");

  const existing = collection.fields.getByName("mercado_pago_access_token");
  if (existing) {
    if (existing.type === "text") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("mercado_pago_access_token"); // exists with wrong type, remove first
  }

  collection.fields.add(new TextField({
    name: "mercado_pago_access_token",
    required: false
  }));

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("teachers");
    collection.fields.removeByName("mercado_pago_access_token");
    return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})