/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("enrollments");

  const existing = collection.fields.getByName("enrollment_type");
  if (existing) {
    if (existing.type === "select") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("enrollment_type"); // exists with wrong type, remove first
  }

  collection.fields.add(new SelectField({
    name: "enrollment_type",
    values: ["avulso", "semanal"]
  }));

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("enrollments");
  collection.fields.removeByName("enrollment_type");
  return app.save(collection);
})